Migration relative charts, 2020–2025

Contents
--------
01_net_change_vs_previous_year.png
    Change in annual net migration compared with the prior year, in thousands.

02_net_change_vs_2020.png
    Difference between each year's net migration and the 2020 level, in thousands.

03_annual_net_as_pct_uk_born_benchmark.png
    Annual net migration by nationality group as a share of a fixed UK-born benchmark.

04_annual_outflows_as_pct_uk_born_benchmark.png
    Annual migration outflows by nationality group as a share of the same benchmark.

05_overall_net_and_outflows_as_pct_uk_born_benchmark.png
    Overall net migration and overall outflows as shares of the same benchmark.

06_cumulative_net_as_pct_uk_born_benchmark.png
    Cumulative net migration since 2020 by nationality group as a share of the same benchmark.

Definitions and cautions
------------------------
The UK-born benchmark is approximately 57.4 million residents. It is a fixed illustrative benchmark,
not an annual denominator. It is derived from the ONS mid-2021 UK population estimate of 67.0 million
less the ONS estimate of 9.6 million non-UK-born residents in YE June 2021.

UK-born residents are not the same thing as British citizens. Some UK-born residents are not British
citizens, while some British citizens were born outside the UK.

The ONS annual population-by-country-of-birth series was discontinued after June 2021 because of an
underlying data issue. Therefore these charts do not claim to show each year's migration flows divided
by that year's UK-born population.

Migration figures are ONS long-term migration YE December estimates rounded to the nearest thousand.
Overall values are sums of rounded group components and can differ slightly from separately published
headline totals due to rounding.
